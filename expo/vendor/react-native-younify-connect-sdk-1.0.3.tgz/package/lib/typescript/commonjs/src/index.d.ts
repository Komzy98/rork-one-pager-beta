/** Error codes reported by the SDK. */
export declare enum ErrorCode {
    /** An unknown error occurred. */
    Unknown = "-10000",
    /** The current version of the SDK is no longer supported. */
    SDKVersionNotSupported = "-10001",
    /** The system is currently down for maintenance. */
    SystemMaintenance = "-10002",
    /** A network error occurred. The user is either offline or the server returned an invalid response. The specific http status code is available in the statusCode property of the userInfo dictionary. */
    NetworkRequestFailed = "-10003",
    /** The requested operation has been canceled. */
    OperationCanceled = "-10004",
    /** An invalid argument was encountered. */
    InvalidArgument = "-10005",
    /** The service fetch operation failed. */
    ServiceFetchingFailed = "-20000",
    /** The service linking operation failed. */
    ServiceLinkingFailed = "-20001",
    /** The service is not supported by the SDK. */
    ServiceUnsupported = "-20002",
    /** The service is temporarily unavailable. */
    ServiceTemporarilyUnavailable = "-20003",
    /** The service login failed. The user should verify their login information. */
    ServiceLoginFailed = "-20004",
    /** The service profile was not found. The user should select another profile. */
    ServiceProfileNotFound = "-20005",
    /** The service profile pin was not correct. The user should enter their pin again. */
    ServiceProfilePinMismatch = "-20006",
    /** This service content may no longer be available. */
    ServiceContentNotFound = "-20007",
    /** The view context is invalid. */
    InvalidViewContext = "-30000",
    /** The user tried to perform an action that requires privacy policy consent. */
    UserConsentRequired = "-40000"
}
/**
 * Contains partial response data for an operation that was promise rejected.
 *
 * Some operations can return valid, partial data despite having errors occur that an application may which to treat as non-fatal.
 */
export interface ErrorUserInfoPartialResult {
    /**
     * Holds the response that would have been returned had an error not occurred but in an incomplete or partial state. The format is identical to the promised value of the original request.
     */
    partialResult?: any | null;
}
/**
 * Contains extra information for {@link ErrorCode.NetworkRequestFailed} errors.
 */
export interface ErrorUserInfoNetworkRequestFailed extends ErrorUserInfoPartialResult {
    /** HTTP status code. */
    statusCode: number;
}
/**
 * Contains extra information for {@link ErrorCode.InvalidArgument} errors.
 */
export interface ErrorUserInfoInvalidArgument extends ErrorUserInfoPartialResult {
    /** Name of the parameter that is invalid. */
    paramName: string;
}
/**
 * Contains extra information for {@link ErrorCode.ServiceLinkingFailed} errors.
 */
export interface ErrorUserInfoServiceLinkingFailed extends ErrorUserInfoPartialResult {
    /** Streaming service specific error message. */
    serviceMessage: string;
}
/** Error object. */
export interface Error extends globalThis.Error {
    /** Code */
    code: ErrorCode | string;
    /** Message */
    message: string;
    /** Info */
    userInfo: ErrorUserInfoServiceLinkingFailed | ErrorUserInfoInvalidArgument | ErrorUserInfoNetworkRequestFailed | ErrorUserInfoPartialResult | object | null;
}
/**
 * Log level.
 */
export declare enum LogLevel {
    /** Trace. */
    Trace = 0,
    /** Debug. */
    Debug = 1,
    /** Information */
    Information = 2,
    /** Warning */
    Warning = 3,
    /** Error */
    Error = 4,
    /** Critical */
    Critical = 5,
    /** None */
    None = 6
}
/**
 * Log listener.
 */
export interface LogListener {
    /** Receives messages from the sdk. */
    onMessage(level: LogLevel, message: string): void;
}
/**
 * Token handler.
 *
 * Implement this handler to receive token events from the sdk and to handle backend token renewals. The instance can be set in {@link ConnectOptions}.
*/
export interface TokenHandler {
    /**
     * Called when an access token is missing or expired that must be renewed via the backend.
     *
     * @param expiredAccessToken - The user's expired access token.
     * @param refreshToken - The user's refresh token for the expired access token.
     * @param renewed - The completion handler to be called with the new access and refresh tokens on success or nil if it fails.
     *
     * This method will be called when an access token is missing or expired and needs renewing via the backend. The SDK will first attempt automatic renewal of tokens via the frontend, but if this fails because
     * the refresh token is missing, revoked or of some other error, a backend renewal will be required. Backend renewals require proxying the request through your own backend api to Younify using your private api key.
     * The renewed completion handler must be called with the new tokens or null if an error occurs. As a convenience, {@link onRenewed} will be called afterward on success to persist the new tokens in device storage.
     */
    onRenew(expiredAccessToken: string | null, refreshToken: string | null, renewed: (newAccessToken: string | null, newRefreshToken: string | null) => void): void;
    /**
     * Called when an access token and refresh token are renewed and need persisted.
     *
     * @param newAccessToken - The user's newly acquired access token.
     * @param newRefreshToken - The user's newly acquired refresh token.
     *
     * This method will be called when an access token and refresh token have been renewed and need persisted. The listener should persisted the new tokens in device local storage in a non-cloud-synchronized manner.
     * If the tokens are accidentally shared between multiple devices, frontend renewal on one device may cause the other devices to be logged out triggering a backend renewal request via {@link onRenew}.
     */
    onRenewed(newAccessToken: string, newRefreshToken: string): void;
}
/**
 * A Cancellation ticket.
 *
 * A special ticket that allows coordination of cancellation operations between a requestor and worker.
 *
 */
export declare class CancellationTicket {
    private static _nextId;
    private static _none;
    static get none(): CancellationTicket;
    private readonly id;
    private canceled;
    constructor();
    /**
     * Whether a cancellation has been requested.
     */
    get isCancellationRequested(): boolean;
    /**
     * @throws {@link Error} if {@link isCancellationRequested} is set.
     */
    throwIfCancellationRequested(): void | never;
    /**
     * Requests that the coordinated operation be canceled and causes {@link isCancellationRequested} to be set.
     *
     * @returns A promise that resolves to a bool indicating whether the cancel was successful.
     */
    cancel(): Promise<void>;
}
/**
 * Younify Connect SDK startup options.
 *
 * Set the properties of this object to configure the sdk.
 * The {@link key} and {@link tokenHandler} properties are required.
 * The {@link accessToken} and {@link refreshToken} properties are required for linking and fetching service content for the user and can be set at a later time if unknown at startup. The tokens can be created from the backend api.
 * The {@link tokenHandler} must be set to handle updated tokens and requests from the sdk to renew tokens from the backend api.
 */
export interface ConnectOptions {
    /** Required key. */
    key: string | null;
    /** Minimum log level. Log statements below {@link logLevel} will not be sent to {@link logListener}. */
    logLevel: LogLevel;
    /** Optional log listener for receiving log events. */
    logListener?: LogListener | null;
    /** Optional token handler for handling token events and renewals. */
    tokenHandler: TokenHandler | null;
    /** The user's access token if known at startup. */
    accessToken?: string | null;
    /** The user's refresh token if known at startup. */
    refreshToken?: string | null;
    /** Extra options. */
    extra?: object | null;
}
/**
 * Streaming service link.
 *
 * Contains informative user properties about the linked streaming service.
 */
export interface StreamingServiceLink {
    /** Service username or email. */
    username: string | null;
    /** Selected profile name if the service has profiles. */
    profileName?: string;
    /** Selected profile image if the service has profiles. */
    profileImageUrl?: string;
    /** Whether this profile is pin protected if the service has profiles. */
    isProfilePINProtected: boolean;
    /** Whether this link is broken or otherwise has a problem that requires management or unlinking to address. */
    isBroken: boolean;
}
/**
 * Streaming service.
 *
 * Represents a streaming service.
 */
export interface StreamingService {
    /** Streaming service id. */
    id: string;
    /** Streaming service name. */
    name: string;
    /** Streaming service small thumbnail image url. */
    smallThumbnailUrl?: string;
    /** Streaming service large thumbnail image url. */
    largeThumbnailUrl?: string;
    /** Streaming service overlay image url. */
    overlayThumbnailUrl?: string;
    /** Whether this streaming service is currently available or is undergoing maintenance. */
    isAvailable: boolean;
    /** Streaming service link info if this service was linked by the user. */
    link?: StreamingServiceLink;
    /** Tests for equality. */
    equals(obj: StreamingService): boolean;
}
/**
 * Streaming service content type.
 *
 * The type of content the {@link StreamingContent} object represents.
 */
export declare enum StreamingContentType {
    /** Invalid type */
    Invalid = -1,
    /** Folder */
    Folder = 0,
    /** Video */
    Video = 1
}
/**
 * Streaming service content.
 *
 * Represents a content item from a streaming service.
 */
export interface StreamingContent {
    /** Content type. */
    type: StreamingContentType;
    /** Name in the {@link path} hierarchy derived from {@link season}, {@link episode} and {@link title}. */
    name: string;
    /** Title. */
    title: string;
    /** Overview, synopsis or description. */
    overview?: string;
    /** Duration in milliseconds. */
    duration: number;
    /** Air date in unix time. */
    airDate?: number;
    /** Small thumbnail image url. */
    smallThumbnailUrl?: string;
    /** Large thumbnail image url. */
    largeThumbnailUrl?: string;
    /** Streaming service specific content id for this item. */
    itemID?: string;
    /** Series title. */
    series?: string;
    /** Series season. */
    season?: string;
    /** Series episode. */
    episode?: string;
    /** Release year. */
    releaseYear?: string;
    /** Content rating. */
    contentRating?: string;
    /** Streaming service specific watch now url. */
    watchNowUrl?: string;
    /** TMDB id for this content if available. */
    tmdbID?: string;
    /** TMDB id for this content's series if available. */
    tmdbSeriesID?: string;
    /** Path to this item as a sequence of parent {@link name} properties. */
    path: string[];
}
/**
 * Streaming service content details.
 *
 * Holds additional content item details for a {@link StreamingContent} object.
 */
export interface StreamingContentDetails {
    /** Estimated duration in milliseconds of this item including advertisements. */
    estimatedDuration: number;
}
/**
 * Streaming service content category.
 *
 * Represents a streaming service category for a user.
 */
export interface StreamingCategory {
    /** Category name. */
    name: string;
    /** Tests for equality. */
    equals(obj: StreamingCategory): boolean;
}
/**
 * Well-known streaming service content categories.
 *
 * Holds a list of well-known streaming service categories.
*/
export declare namespace StreamingCategories {
    /** Your Watchlist. */
    const YourWatchlist: StreamingCategory;
    /** Continue Watching. */
    const ContinueWatching: StreamingCategory;
    /** Recommended for You. */
    const RecommendedForYou: StreamingCategory;
    /** Trending &amp; Popular. */
    const TrendingAndPopular: StreamingCategory;
    /** Critically Acclaimed. */
    const CriticallyAcclaimed: StreamingCategory;
}
/**
 * Fetch content category service result.
 *
 * Holds the results of a fetch content request for a given streaming service.
 */
export interface FetchContentCategoryServiceResult {
    /** Streaming service the content items belong to. */
    service: StreamingService;
    /** Content items for {@link service}. */
    content: StreamingContent[];
}
/**
 * Fetch content category result.
 *
 * Holds the results of a fetch content request for a category and each streaming service
 */
export interface FetchContentCategoryResult {
    /** Streaming category the results apply to. */
    category: StreamingCategory;
    /** Service results for the specified category. */
    services: FetchContentCategoryServiceResult[];
}
/**
 * Search content service result.
 *
 * Holds the results of a search content request for a given streaming service.
 */
export interface SearchContentServiceResult {
    /** Streaming service the content items belong to. */
    service: StreamingService;
    /** Content items for {@link service}. */
    content: StreamingContent[];
}
/**
 * Younify Connect SDK main interface.
 *
 * Caution: When invoking a method, the sdk uses a limited task based processing architecture that may delay the execution of new operations until previous ones complete.
 * Special care should be taken when performing sdk operations in the background while allowing the user to interact in the foreground. Long running background operations
 * could negatively impact the responsiveness of your app. If you choose to use background operations, consider making them as short as possible or cancel them when users
 * interact in the foreground.
 */
export interface IConnect {
    /**
     * Configures the SDK with the specified options.
     * @param options - The configuration options.
     *
     * Before using the sdk it must be configured by using this method with a valid {@link ConnectOptions} instance. It is safe to call this method repeatedly to change the options dynamically at runtime if desired.
    */
    configure(options: ConnectOptions): Promise<void>;
    /**
     * Clears all user data.
     *
     * User data locally persisted on device or retained in memory will be cleared, including user tokens.
     */
    clearUserData(): Promise<void>;
    /**
     * Sets the user's tokens.
     *
     * @param accessToken - The user's access token.
     * @param refreshToken - The user's refresh token.
     *
     * Set the user's access and refresh tokens that are required for accessing streaming services. User tokens can be obtained by creating a user object from the backend api.
     */
    setUserTokens(accessToken: string | null, refreshToken: string | null): Promise<void>;
    /**
     * Determines if the user has required pending consent actions.
     *
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns A boolean indicating whether there are pending consents or not.
     */
    requiresUserConsent(cancellationTicket: CancellationTicket | null): Promise<boolean>;
    /**
     * Requests the user to consent to the privacy policy if it has not yet been accepted.
     *
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns A boolean indicating whether the user consented to all mandatory documents or false if they did not.
     *
     * Opens the legal document consent flow if consents are pending or returns immediately with true if all consents are satisfied.
     */
    requestUserConsent(cancellationTicket: CancellationTicket | null): Promise<boolean>;
    /**
     * Link a streaming service.
     *
     * @param service - The service object to link.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns A boolean indicating whether the service was linked or not.
     *
     * Opens the service linking flow which involves a web view login for the specified service followed by profile selection and optional pin collection if supported.
     * If linking is successful, the success flag will be true. If linking was canceled then the success flag will be false. If linking fails the promise will reject.
     *
     * Caution: Given the task based architecture of the sdk and the asynchronous nature of this method, care should be taken when invoking it from user interactive
     * elements to debounce or otherwise prevent multiple invocations until the previous one completes.
     */
    linkService(service: StreamingService, cancellationTicket: CancellationTicket | null): Promise<boolean>;
    /**
     * Manage a linked service.
     *
     * @param service - The service object to manage.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns The service object that was managed.
     *
     * Opens the linked service management flow which allows the user to change their profile selection and pin if supported.
     *
     * Caution: Given the task based architecture of the sdk and the asynchronous nature of this method, care should be taken when invoking it from user interactive
     * elements to debounce or otherwise prevent multiple invocations until the previous one completes.
     */
    manageLinkedService(service: StreamingService, cancellationTicket: CancellationTicket | null): Promise<void>;
    /**
     * Unlink a linked service.
     *
     * @param service - The service object to unlink.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns The service object that was unlinked.
     *
     */
    unlinkService(service: StreamingService, cancellationTicket: CancellationTicket | null): Promise<void>;
    /**
     *
     * Fetch all services.
     *
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns All services.
     *
     * Retrieves a list of all services.
     */
    fetchServices(cancellationTicket: CancellationTicket | null): Promise<StreamingService[]>;
    /**
     * Fetch linked services.
     *
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns All linked services.
     *
     * Retrieves a list of all the user's linked services.
     */
    fetchLinkedServices(cancellationTicket: CancellationTicket | null): Promise<StreamingService[]>;
    /**
     * Fetch linked services.
     *
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns All broken services.
     *
     * Retrieves a list of all the user's broken services.
     */
    fetchBrokenServices(cancellationTicket: CancellationTicket | null): Promise<StreamingService[]>;
    /**
     * Fetch all streaming categories.
     *
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns All streaming categories.
     *
     * Retrieves a list of all streaming categories.
     */
    fetchCategories(cancellationTicket: CancellationTicket | null): Promise<StreamingCategory[]>;
    /**
     * Fetch streaming category contents.
     *
     * @param categories - The list of categories to fetch content for.
     * @param services - The list of streaming services to fetch content for.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @param serviceError - The optional error handler to call when a problem occurs accessing a service.
     * @param categoryServiceComplete - The optional completion handler to call when retrieving content for a single category and service.
     * @returns Complete fetched content for all services and all categories or an empty array if `categoryServiceComplete` is non-null.
     *
     * Retrieves the content for the `categories` and `services` specified.
     * `serviceError` will be called when a service error occurs.
     * `categoryServiceComplete` will be called with the results for a single category-service pair. Specifying this callback will cause the response promise to resolve with an empty array for performance.
     */
    fetchContent(categories: StreamingCategory[], services: StreamingService[], cancellationTicket: CancellationTicket | null, serviceError: ((service: StreamingService, error: Error) => void) | null, categoryServiceComplete: ((category: StreamingCategory, service: StreamingService, content: StreamingContent[], error: Error | null) => void) | null): Promise<FetchContentCategoryResult[]>;
    /**
     * Fetch content children.
     *
     * @param content - The parent content item to fetch children for.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns The children of the requested `content` item.
     *
     * Retrieves the children of the given parent `content` object. The `content` object must be a folder to have children.
     *
     * Examples include using a `content` that represents a series where the children would be its seasons, or a `content` that represents a season where the children would be its episodes.
     */
    fetchContentChildren(content: StreamingContent, cancellationTicket: CancellationTicket | null): Promise<StreamingContent[]>;
    /**
     * Fetch content details.
     *
     * @param content - The content item to retrieve details for.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns The details of the requested `content` item.
     *
     * Retrieves `content` details.
     *
     * Details or additional metadata properties currently include browse path and estimated durations.
     */
    fetchContentDetails(content: StreamingContent, cancellationTicket: CancellationTicket | null): Promise<StreamingContentDetails>;
    /**
     * Search a streaming service.
     *
     * @param services - The streaming service to search.
     * @param searchPhrase - The list of streaming services to fetch content for.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @param serviceComplete - The optional completion handler to call when retrieving search results for a single service.
     * @returns Complete search results for all services or an empty array if `serviceComplete` is non-null.
     *
     * Searches the given `services` with the specified `searchPhrase`.
     * `serviceComplete` will be called with the results for a single service. Specifying this callback will cause the response promise to resolve with an empty array for performance.
     */
    searchContent(services: StreamingService[], searchPhrase: string, cancellationTicket: CancellationTicket | null, serviceComplete: ((service: StreamingService, content: StreamingContent[], error: Error | null) => void) | null): Promise<SearchContentServiceResult[]>;
    /**
     * Fetch an image.
     *
     * @param url - The image url to fetch.
     * @param cancellationTicket - The ticket to manually cancel the operation.
     * @returns Image data as a base64 string.
     *
     * Retrieves the image from the specified image `url`.
     *
     * Directly fetching image urls in any other way can lead to missing data or 404s depending on the streaming service.
     */
    fetchImage(url: string, cancellationTicket: CancellationTicket | null): Promise<string>;
}
/**
 * Younify Connect SDK main object.
 *
 * Use the {@link shared} singleton instance to interact with the sdk. Before the sdk can be meaningfully used {@link configure} must be called.
 */
export declare class Connect implements IConnect {
    private static instance;
    static get shared(): Connect;
    private _logListener;
    private _logListenerSubscriptions;
    private _tokenHandler;
    private _tokenHandlerSubscriptions;
    private _nextRequestId;
    private constructor();
    private callBridge;
    private updateService;
    private checkCancellationTicketAndGetId;
    configure(options: ConnectOptions): Promise<void>;
    clearUserData(): Promise<void>;
    setUserTokens(accessToken: string | null, refreshToken: string | null): Promise<void>;
    requiresUserConsent(cancellationTicket: CancellationTicket | null): Promise<boolean>;
    requestUserConsent(cancellationTicket: CancellationTicket | null): Promise<boolean>;
    linkService(service: StreamingService, cancellationTicket: CancellationTicket | null): Promise<boolean>;
    manageLinkedService(service: StreamingService, cancellationTicket: CancellationTicket | null): Promise<void>;
    unlinkService(service: StreamingService, cancellationTicket: CancellationTicket | null): Promise<void>;
    fetchServices(cancellationTicket: CancellationTicket | null): Promise<StreamingService[]>;
    fetchLinkedServices(cancellationTicket: CancellationTicket | null): Promise<StreamingService[]>;
    fetchBrokenServices(cancellationTicket: CancellationTicket | null): Promise<StreamingService[]>;
    fetchCategories(cancellationTicket: CancellationTicket | null): Promise<StreamingCategory[]>;
    fetchContent(categories: StreamingCategory[], services: StreamingService[], cancellationTicket: CancellationTicket | null, serviceError: ((service: StreamingService, error: Error) => void) | null, categoryServiceComplete: ((category: StreamingCategory, service: StreamingService, content: StreamingContent[], error: Error | null) => void) | null): Promise<FetchContentCategoryResult[]>;
    fetchContentChildren(content: StreamingContent, cancellationTicket: CancellationTicket | null): Promise<StreamingContent[]>;
    fetchContentDetails(content: StreamingContent, cancellationTicket: CancellationTicket | null): Promise<StreamingContentDetails>;
    searchContent(services: StreamingService[], searchPhrase: string, cancellationTicket: CancellationTicket | null, serviceComplete: ((service: StreamingService, content: StreamingContent[], error: Error | null) => void) | null): Promise<SearchContentServiceResult[]>;
    fetchImage(url: string, cancellationTicket: CancellationTicket | null): Promise<string>;
}
//# sourceMappingURL=index.d.ts.map