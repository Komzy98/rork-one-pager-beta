//
// Copyright © 2024 MediaMall Technologies, Inc.  All rights reserved.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <YounifyConnectSDK/Logging.h>
#import <YounifyConnectSDK/Tokens.h>

@interface YCSRModule : RCTEventEmitter <RCTBridgeModule, YCSLogDelegate, YCSTokenDelegate>

@end
