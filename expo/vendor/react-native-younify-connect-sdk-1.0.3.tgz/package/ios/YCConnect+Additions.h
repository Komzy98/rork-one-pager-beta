//
// Copyright © 2024 MediaMall Technologies, Inc.  All rights reserved.
//

#import <Foundation/Foundation.h>
#import <YounifyConnectSDK/YounifyConnectSDK.h>

NS_ASSUME_NONNULL_BEGIN


@interface YCSRErrorEnum : NSObject

+ (NSString *)toString:(YCSError)value;

@end


@interface NSError (YCSRNSErrorAdditions)

- (NSString *)codeString;
- (NSDictionary *)JSONDictionary;

@end


@interface YCSRLogLevelEnum : NSObject

+ (NSString *)toString:(YCSLogLevel)value;
+ (YCSLogLevel)fromString:(NSString *)value;
+ (YCSLogLevel)fromObject:(id)value;

@end


@interface YCSConnectOptions (YCSRConnectOptionsAdditions)

- (instancetype)initWithJSONDictionary:(NSDictionary *)dict;

@end


@interface YCSStreamingServiceLink (YCSRStreamingServiceLinkAdditions)

- (instancetype)initWithJSONDictionary:(NSDictionary *)dict;
- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSStreamingService (YCSRStreamingServiceAdditions)

- (instancetype)initWithJSONDictionary:(NSDictionary *)dict;
- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSRStreamingContentTypeEnum : NSObject

+ (NSString *)toString:(YCSStreamingContentType)value;
+ (YCSStreamingContentType)fromString:(NSString *)value;
+ (YCSStreamingContentType)fromObject:(id)value;

@end


@interface YCSStreamingContent (YCSRStreamingContentAdditions)

- (instancetype)initWithJSONDictionary:(NSDictionary *)dict;
- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSStreamingContentDetails (YCSRStreamingContentDetailsAdditions)

- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSStreamingCategory (YCSRStreamingCategoryAdditions)

- (instancetype)initWithJSONDictionary:(NSDictionary *)dict;
- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSFetchContentCategoryServiceResult (YCSRFetchContentCategoryServiceResultAdditions)

- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSFetchContentCategoryResult (YCSRFetchContentCategoryResultAdditions)

- (NSMutableDictionary *)JSONDictionary;

@end


@interface YCSSearchContentServiceResult (YCSRSearchContentServiceResultAdditions)

- (NSMutableDictionary *)JSONDictionary;

@end


NS_ASSUME_NONNULL_END
