# react-native-younify-connect-sdk

Younify Connect SDK for React Native

## Installation

```sh
npm install react-native-younify-connect-sdk-{version}.tgz
```

### iOS

```sh
cd ios
pod install
```

### Android

Add the following maven repository to your `android/build.gradle` file:
```groovy
allprojects {
    repositories {
        maven() { url "${rootProject.rootDir}/../node_modules/react-native-younify-connect-sdk/android/deps" }
        ...
    }
}
```

## Usage

```js
import { Connect, LogLevel, type ConnectOptions, type TokenHandler } from "react-native-younify-connect-sdk";

const connect = Connect.shared;
const options = new ConnectOptions()
{
    key: "<your sdk key>",
    logLevel: LogLevel.Warning,
    tokenHandler: new class implements TokenHandler
    {
        onRenew(expiredAccessToken: string | null,
                refreshToken: string | null,
                renewed: (newAccessToken: string | null, newRefreshToken: string | null) => void): void
        {
            // Make a backend Younify api call to create a new user or recreate the tokens for an existing user.
            // To keep your Younify api key secure, this request must be proxied to your own backend servers first.
            // Once the new tokens are retrieved, `renewed` must be called with the new tokens or null in case of error.
            // As a convenience `onRenewed` will be called automatically to persist the new tokens.
            //
            // renewed("<the user's new access token | null>", "<the user's new refresh token | null>");
            throw new Error("Not Implemented");
        }

        onRenewed(newAccessToken: string, newRefreshToken: string): void
        {
            // Persist the user's new access token and new refresh token in secure storage.
            // The secure storage utilized must be per device and not cloud synchroznied in a way
            // that would permit multiple devices to use the same tokens. Doing so can lead
            // to all other devices being logged out.
            throw new Error("Not Implemented");
        }
    },
    accessToken: "<retrieve the user's access token from secure storage | null>",
    refreshToken: "<retrieve the user's refresh token from secure storage | null>"
};
await connect.configure(options);
// ...
const result = await connect.fetchServices();
```

## License

```
This License Agreement ("Agreement") is made by and between MediaMall Technologies, Inc. ("Licensor") and you ("Licensee"), effective as of the date of digital acceptance or implementation of the Younify Connect SDK for React Native (the "SDK").

1. Grant of License: Licensor hereby grants to Licensee a non-exclusive, non-transferable, revocable license to use the SDK solely for the purpose of integrating with the Younify Data API to access users’ streaming account viewing activity. This license does not grant the right to sublicense, modify, distribute, or create derivative works of the SDK.

2. Intellectual Property: The SDK, including but not limited to its code, structure, and organization, is the proprietary information and intellectual property of the Licensor and is protected by intellectual property laws. The Licensee agrees to take all reasonable steps to protect the SDK from unauthorized copying or use.

3. Restrictions: The Licensee shall not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products or services obtained from the SDK.

4. No Warranty: The SDK is provided "as is" and without warranties of any kind, either expressed or implied. Licensor disclaims all warranties, including any implied warranties of merchantability, fitness for a particular purpose, and non-infringement.

5. Attribution: Licensee agrees to include appropriate attribution to “Younify Connect SDK for React Native by MediaMall Technologies, Inc.” in any software or application that integrates with the SDK.

6. Termination: This Agreement may be terminated by either party at any time with or without cause. Upon termination, the Licensee must cease all use of the SDK and destroy all copies, full or partial, of the SDK.

7. Governing Law: This Agreement shall be governed by and construed in accordance with the laws of the state of Washington, without regard to its conflict of law principles.

8. Limitation of Liability: In no event shall Licensor be liable for any special, incidental, indirect, or consequential damages whatsoever arising out of or in connection with the use of or inability to use the SDK.

9. Entire Agreement: This Agreement constitutes the entire agreement between the parties with respect to the subject matter hereof and supersedes all prior or contemporaneous oral or written agreements and understandings.

By using the SDK, the Licensee agrees to be bound by the terms of this Agreement.
```