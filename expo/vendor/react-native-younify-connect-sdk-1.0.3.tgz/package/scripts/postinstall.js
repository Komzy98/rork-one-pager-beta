#!/usr/bin/env node

const decompress = require("decompress");

decompress("ios/YounifyConnectSDK.xcframework.zip", "ios")
  .then((files) =>
  {
    console.log("---------- Additional Manual Setup [IOS] ----------\n");
    console.log("cd ios");
    console.log("pod install");
    console.log("\n");

    console.log("---------- Additional Manual Setup [ANDROID] ----------\n");
    console.log("Add the following maven repository to your build.gradle\n");
    console.log("allprojects {");
    console.log("  repositories {");
    console.log("    maven() { url \"${rootProject.rootDir}/../node_modules/react-native-younify-connect-sdk/android/deps\" }");
    console.log("    ...");
    console.log("  }");
    console.log("}");
    console.log("\n");
  })
  .catch((error) =>
  {
    console.error(error);
  });
